#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include "std_msgs/String.h"
#include <sstream>

int main(int argc, char **argv){

  ros::init(argc, argv, "talker");
  ros::NodeHandle nodo;
  ros::Publisher pub = nodo.advertise<std_msgs::Int32>("chatter", 1000);

  
  //@DG
  int32_t count=2;
  std_msgs::Int32 msg;

  ros::Duration durTime(5,0);
  
  while (ros::ok()){

    msg.data = count;

    
    ROS_INFO("%d", msg.data);//.equals printf

    pub.publish(msg);

    //
    ros::spinOnce();

    //@DG[1]
    durTime.sleep();//cada 5 segundos
    count++;

 }


  return 0;
}